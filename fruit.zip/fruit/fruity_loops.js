/* array of our fruits */
let fruits = ["Apple", "Orange", "Banana", "Pear", "Peach", "Strawberry", "Cherry", "Acia"];

for (let fruit in fruits) {
  let vowels = 0;
  let consonants = 0;
  /* checking each fruit and its strings*/
  for (let i = 0; i < fruits[fruit].length; i++) {
    /* for string being an vowel */
    if(fruits[fruit][i] == 'A' || fruits[fruit][i] == 'E' || fruits[fruit][i] == 'I' || fruits[fruit][i] == 'O' ||
       fruits[fruit][i] == 'U' || fruits[fruit][i] == 'a' || fruits[fruit][i] == 'e' || fruits[fruit][i] == 'i' ||
       fruits[fruit][i] == 'o' || fruits[fruit][i] == 'u'){
        vowels++;
    }
    else{
        consonants++;
    }
  }

  /* how many vowels and consonants for each fruit */ 
console.log(fruits[fruit], "Has vowels: ", vowels, "And consonants: ", consonants);

}
