/* get values */
alert("Number 1");
var firstValue = window.prompt("Enter a number: ");

alert("Number 2");
var secondValue = window.prompt("Enter another number: ");

alert("Operation");
var operation = window.prompt("Enter a operation ( + - / * ^ ): ")


/* declare functions and do the operations */
function addition(firstValue, secondValue){
  /*convert a string to a number using the unary + operator*/
  return +firstValue + +secondValue;
}
/* other operators / * -  perform a toNumber conversion on the string(s) */
function subtraction(firstValue, secondValue){
  return firstValue - secondValue;
}

function division(firstValue, secondValue){
  return firstValue / secondValue;
}

function multiplication(firstValue, secondValue){
  return firstValue * secondValue;
}

/* the caret symbol in JS is XOR operator :) */
function caret(firstValue, secondValue){
  /* Math.pow() will calculate for ex. x² */
  return Math.pow(firstValue, secondValue);
}

/* Condition - output the gives caluclating result */
switch(operation){
  case '+':
    console.log(firstValue, operation, secondValue, " = ", addition(firstValue, secondValue)); 
    break;
  case '-':
     console.log(firstValue, operation, secondValue, " = ", subtraction(firstValue, secondValue));
    break;
  case '/':
     console.log(firstValue, operation, secondValue, " = ", division(firstValue, secondValue));
    break;
  case '*':
     console.log(firstValue, operation, secondValue, " = ", multiplication(firstValue, secondValue));
    break;
  case '^':
     console.log(firstValue, operation, secondValue, " = ", caret(firstValue, secondValue));
    break;
  default:
    console.log("Code does not work");
}




