/* Task 3: TechTalent-athon
register runners for race */

/* Race number 0 - 999 */
let raceNumber = Math.floor(Math.random() * 1000);

/* declaring variables */
var registrationTime = Boolean;
var runnerAge = 17;

/* if runner is above 18 and early will get +1000 race number */
if(runnerAge > 18 && registrationTime == true){
  raceNumber = raceNumber + 1000;
}

/* For early adults */
if(runnerAge > 18 && registrationTime == true){
  console.log("Number:", raceNumber, "age:", runnerAge, "you will race at 9:30am");
}

/* For late adults */
else if(runnerAge > 18 && registrationTime == false){
  console.log("Number:", raceNumber, "age:", runnerAge, "late adults run at 11.00am");
}

/* For youth runners */
else if(runnerAge < 18){
  console.log("Number:", raceNumber, "age:", runnerAge, "youth registrants run at 12.30am");
}

/* For those who are 18 */
else if(runnerAge == 18){
  console.log("Number:", raceNumber, "age:", runnerAge, "please check the registration desk");
}
