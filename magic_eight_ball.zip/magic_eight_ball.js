// Task 2: Magic Eight Ball for telling fortunes 

/* Declaring an empty string variable */
var userName = '';

/* Opens a new window asking for user input (name) */
userName = window.prompt("Enter your name: "); 

/* Creates a condition - 
based on user input */
/* length - checks the number of strings*/
/* if the number is more than 0 */
if (userName.length > 0) {
 // output this
  console.log("Hello,", userName);
}
/* if not then check if the number of 
strings is equal to 0 */
else if (userName.length == 0) {
 // if yes, output next line
  console.log("Hello!");
}

/* creates a empty string */
var userQuestion = '';

// ask for user input
userQuestion = window.prompt("Enter your question: ");

/* output the following question said
by user */
console.log("The user", userName ,"asked following question: ", userQuestion);

/* using both methods
math.floor() - for rounding down numbers and 
math.random() - for generating a random number from 0 - 7 
( 8 cause we are counting from 0 :)*/
var randomNumber = Math.floor(Math.random() * 8);

var eightBall = '';

/* switch statements based on our
randomNumber */
switch(randomNumber){
  /* if the number is 0 */
  case 0: 
    eightBall = 'It is certain';
    /* break to go to next case if 
    the number is not 0 */
    break;
  case 1:
    eightBall = 'It is decidedly so';
    break;
  case 2:
    eightBall = 'Reply hazy try again';
    break;
  case 3:
    eightBall = 'Cannot predict now';
    break;
  case 4:
    eightBall = 'Do not count on it';
    break;
  case 5:
    eightBall = 'My sources say no';
    break;
  case 6:
    eightBall = 'Outlook not so good';
    break;
  case 7:
    eightBall = 'Signs point to yes';
    break;   
    /* if none of cases match our     
    number*/
  default: 
    console.log("Incorrect");
}

/* Output answer to our question :) */
console.log(userName, "The answer to your question is: ", eightBall);