/* Task 1. JavaScript Kelvin Weather 
 converting Kelvin -> Celsius -> Fahrenheit*/

/* Today foreceast: 293 Kelvin (K)
    Declaration of const kelvin and celsius*/
const kelvin = 293;
let celsius;

/* Converting kelvin (K) into celsius (°C) by subtracting 
    273 from kelvin */
celsius = kelvin - 273;

/* Using equation Fahrenheit (F) = Celsius * (9/5) + 32
    to convert celsius (°C) to fahrenheit (F) */
let fahrenheit;
fahrenheit = celsius * (9 / 5) + 32;

/* Using in-build Math object called .floor()
   to round down possible decimal numbers  */
fahrenheit = Math.floor(fahrenheit);

// Output the result - temperature
console.log(`The temperature is ${fahrenheit} degress fahrenheit`);
/*or we can use:
console.log("The temperature is", fahrenheit, "degress fahrenheit");
*/

/* 0 kelvin (K) to temperature */
/*
const kelvin = 0;
let celsius;
celsius = kelvin - 273;
let fahrenheit;
fahrenheit = celsius * (9 / 5) + 32;
fahrenheit = Math.floor(fahrenheit);
// Output is: -459F
console.log("The temperature is", fahrenheit , "degrees fahrenheit");
*/
