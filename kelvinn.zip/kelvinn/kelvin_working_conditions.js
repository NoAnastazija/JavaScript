/* necessary variables */
let temperature;
var condition;
var goToWork;

/* values input */
alert("Temperature");
temperature = window.prompt("Enter temperature: ");

alert(Weather);
condition = window.prompt("Enter the today weather: Sunny, Cloudy, Raining, Snowing, Thunder");

/* nested switch within if condition */
if(temperature >= 10){
     switch(condition){
       case "Sunny":
         goToWork = "true";
         break;
        case "Cloudy":
         goToWork = "true";
         break;
       case "Raining":
         goToWork = "false, no one likes being wet and cold";
         break;
       case "Snowing":
         goToWork = "false";
         break;
       case "Thunder":
         goToWork = "false, Kelvin you are working with metal";
           break;
       default:
         console.log("switch is not working");
     }
}
     
else if(temperature >= 20){
     switch(condition){
       case "Sunny":
         goToWork = 'true';
         break;
        case "Cloudy":
         goToWork = "true";
         break;
       case "Raining":
         goToWork = "true, being warm and wet is not the worst";
         break;
       case "Snowing":
         goToWork = "false, weather is too weird";
         break;
       case "Thunder":
         goToWork = "false, Kelvin you are working with metal";
           break;
       default:
         console.log("switch is not working");
         break;
     }
}

else if (temperature >= 30){
     switch(condition){
       case "Sunny":
         goToWork = "false, it is too hot to work effectively";
         break;
        case "Cloudy":
         goToWork = "false, it is to hot to work effectively";
         break;
       case "Raining":
         goToWork = "false, it is too hot to work effectively";
         break;
       case "Snowing":
         goToWork = "false, the weather is too weird";
         break;
       case "Thunder":
         goToWork = "false, it is too hot to work effectively";
           break;
       default:
         console.log("switch is not working");
         break;
     }
}

else if(temperature < 10){
     switch(condition){
       case "Sunny":
         goToWork = "false, it is too cold to work effectively";
         break;
        case "Cloudy":
         goToWork = "false, it is too cold to work effectively";
         break;
       case "Raining":
         goToWork = "false, it is too cold to work effectively";
         break;
       case "Snowing":
         goToWork = "false, it is too cold to work effectively";
         break;
       case "Thunder":
         goToWork = "false, it is too cold to work effectively";
           break;
       default:
         console.log("switch is not working");
         break;
     }
}

/* output the answer*/
console.log(goToWork);

